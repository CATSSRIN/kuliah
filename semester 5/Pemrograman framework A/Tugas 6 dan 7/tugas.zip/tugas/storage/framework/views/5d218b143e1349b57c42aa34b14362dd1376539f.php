

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Daftar Proyek</h3>
    <a href="<?php echo e(route('proyek.create')); ?>" class="btn btn-primary">+ Tambah Proyek</a>
</div>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>No</th>
            <th>Judul Proyek</th>
            <th>Mahasiswa (NIM)</th>
            <th>Dosen Pembimbing</th>
            <th>Status</th>
            <th>Dokumen</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $proyeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $proyek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($proyeks->firstItem() + $index); ?></td>
            <td><?php echo e($proyek->judul); ?></td>
            <td><?php echo e($proyek->mahasiswa->nama ?? 'N/A'); ?> (<?php echo e($proyek->mahasiswa->nim ?? 'N/A'); ?>)</td>
            <td><?php echo e($proyek->dosen->nama ?? 'N/A'); ?></td>
            <td><span class="badge bg-info"><?php echo e($proyek->status); ?></span></td>
            <td>
                <?php if($proyek->dokumen): ?>
                    <a href="<?php echo e(asset('storage/'.$proyek->dokumen)); ?>" target="_blank">Lihat</a>
                <?php else: ?>
                    <span class="text-muted">Tidak ada</span>
                <?php endif; ?>
            </td>
            <td>
                <a href="<?php echo e(route('proyek.edit', $proyek->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route('proyek.destroy', $proyek->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="7" class="text-center">Belum ada data proyek.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<div class="d-flex justify-content-center">
    <?php echo e($proyeks->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\kuliah\semester 5\Pemrograman framework A\Tugas 6\tugas\resources\views/proyek/index.blade.php ENDPATH**/ ?>