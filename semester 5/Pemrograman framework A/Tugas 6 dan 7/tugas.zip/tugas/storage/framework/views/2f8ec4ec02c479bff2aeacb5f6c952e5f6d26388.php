

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Daftar Dosen</h3>
    <a href="<?php echo e(route('dosen.create')); ?>" class="btn btn-primary">+ Tambah Dosen</a>
</div>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>No</th>
            <th>NIP</th>
            <th>Nama Lengkap</th>
            <th>Email</th>
            <th>Bidang Keahlian</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $dosens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $dosen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($dosens->firstItem() + $index); ?></td>
            <td><?php echo e($dosen->nip); ?></td>
            <td><?php echo e($dosen->nama); ?></td>
            <td><?php echo e($dosen->email); ?></td>
            <td><?php echo e($dosen->bidang_keahlian); ?></td>
            <td>
                <a href="<?php echo e(route('dosen.edit', $dosen->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route('dosen.destroy', $dosen->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center">Belum ada data dosen.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<div class="d-flex justify-content-center">
    <?php echo e($dosens->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\kuliah\semester 5\Pemrograman framework A\Tugas 6\tugas\resources\views/dosen/index.blade.php ENDPATH**/ ?>