

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Daftar Mahasiswa</h3>
    <a href="<?php echo e(route('mahasiswa.create')); ?>" class="btn btn-primary">+ Tambah Mahasiswa</a>
</div>

<table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>No</th>
            <th>Foto</th>
            <th>NIM</th>
            <th>Nama Lengkap</th>
            <th>Email</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($mahasiswas->firstItem() + $index); ?></td>
            <td>
                <?php if($mhs->foto): ?>
                    <img src="<?php echo e(asset('storage/'.$mhs->foto)); ?>" width="60" class="rounded">
                <?php else: ?>
                    <span class="text-muted">Tidak ada</span>
                <?php endif; ?>
            </td>
            <td><?php echo e($mhs->nim); ?></td>
            <td><?php echo e($mhs->nama); ?></td>
            <td><?php echo e($mhs->email); ?></td>
            <td>
                <a href="<?php echo e(route('mahasiswa.edit', $mhs->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                <form action="<?php echo e(route('mahasiswa.destroy', $mhs->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-sm btn-danger">Hapus</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="6" class="text-center">Belum ada data mahasiswa.</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<div class="d-flex justify-content-center">
    <?php echo e($mahasiswas->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Github\kuliah\semester 5\Pemrograman framework A\Tugas 6\tugas\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>